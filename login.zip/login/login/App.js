import React, { useState } from 'react';
import {
  StyleSheet,
  Text,
  View,
  TextInput,
  TouchableOpacity,
  SafeAreaView,
  StatusBar
} from 'react-native';
import { Mail, Lock, Eye, ShieldPlus, HelpCircle, KeyRound } from 'lucide-react-native';

export default function App() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');

  return (
    <SafeAreaView style={styles.container}>
      <StatusBar barStyle="dark-content" />
     
      {/* Header com Logo e Título */}
      <View style={styles.header}>
        <ShieldPlus color="#00C4CC" size={80} strokeWidth={1.5} />
        <Text style={styles.title}>Faça seu{"\n"}Login!</Text>
      </View>

      {/* Card de Login */}
      <View style={styles.card}>
        <Text style={styles.welcomeText}>Bem-vindo de volta</Text>
        <Text style={styles.subTitle}>Acesse o painel de gestão farmacêutica</Text>

        {/* Input E-mail */}
        <View style={styles.inputContainer}>
          <Mail color="#666" size={20} style={styles.icon} />
          <TextInput
            style={styles.input}
            placeholder="E-mail corporativo"
            value={email}
            onChangeText={setEmail}
            keyboardType="email-address"
            autoCapitalize="none"
          />
        </View>

        {/* Input Senha */}
        <View style={styles.inputContainer}>
          <Lock color="#666" size={20} style={styles.icon} />
          <TextInput
            style={styles.input}
            placeholder="Senha"
            value={password}
            onChangeText={setPassword}
            secureTextEntry
          />
          <TouchableOpacity>
            <Eye color="#666" size={20} />
          </TouchableOpacity>
        </View>

        {/* Botão Entrar */}
        <TouchableOpacity style={styles.button}>
          <Text style={styles.buttonText}>Acessar sistema</Text>
        </TouchableOpacity>

        {/* Footer do Card */}
        <div style={styles.footerRow}>
          <TouchableOpacity style={styles.footerLink}>
            <KeyRound color="#666" size={16} />
            <Text style={styles.footerText}> Esqueci minha senha</Text>
          </TouchableOpacity>

          <TouchableOpacity style={styles.footerLink}>
            <HelpCircle color="#666" size={16} />
            <Text style={styles.footerText}> Suporte</Text>
          </TouchableOpacity>
        </div>
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#E0E0E0', // Fundo cinza claro igual ao Nox
    alignItems: 'center',
    justifyContent: 'center',
  },
  header: {
    alignItems: 'center',
    marginBottom: 30,
  },
  title: {
    fontSize: 32,
    fontWeight: 'bold',
    color: '#00C4CC',
    textAlign: 'center',
    marginTop: 10,
  },
  card: {
    backgroundColor: '#FFF',
    width: '85%',
    borderRadius: 8,
    padding: 25,
    elevation: 5, // Sombra para Android
    shadowColor: '#000', // Sombra para iOS
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
  },
  welcomeText: {
    fontSize: 22,
    fontWeight: 'bold',
    color: '#333',
    textAlign: 'center',
  },
  subTitle: {
    fontSize: 14,
    color: '#666',
    textAlign: 'center',
    marginBottom: 25,
    marginTop: 5,
  },
  inputContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    borderWidth: 1,
    borderColor: '#DDD',
    borderRadius: 6,
    paddingHorizontal: 10,
    height: 50,
    marginBottom: 15,
  },
  icon: {
    marginRight: 10,
  },
  input: {
    flex: 1,
    fontSize: 16,
    color: '#333',
  },
  button: {
    backgroundColor: '#137D72', // Verde petróleo da imagem
    height: 50,
    borderRadius: 6,
    justifyContent: 'center',
    alignItems: 'center',
    marginTop: 10,
    marginBottom: 20,
  },
  buttonText: {
    color: '#FFF',
    fontSize: 16,
    fontWeight: '600',
  },
  footerRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginTop: 5,
  },
  footerLink: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  footerText: {
    fontSize: 12,
    color: '#666',
  },
});